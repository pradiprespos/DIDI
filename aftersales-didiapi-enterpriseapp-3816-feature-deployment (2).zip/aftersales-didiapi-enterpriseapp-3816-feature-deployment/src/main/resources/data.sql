INSERT INTO PARM (C_MKT,C_BRND, I_MOD_YR ,C_BODY_MODEL,C_ENGINE_SC,C_TRANS_SC, C_DLR,C_ZONE, C_LANG, Q_MIS,L_ELIG ,L_REC_STAT 
,X_MSG ,D_STMP_EFF_STRT, D_STMP_EFF_END, C_LOP1_2, C_LOP3_4, C_LOP5_6,C_LOP7_8) 
VALUES ('*','*','*','*','*','*','*','*','*','12','Y','D','CUSTOMMSG1', '2023-01-01','2024-12-31','*','*','*','*'),
       ('*','*','1993','ZJJL74','*','*','*','*','*','6','Y','A','This vehicle has been in service for less than 6 months and require a DIDI for MECH repairs.', '2023-01-01','2024-12-31','*','*','*','*'),
       ('*','JEEP','*','*','*','*','60083','*','*','12','Y','A','This vehicle has been in service for less than 12 months and require a DIDI for MECH repairs.', '2023-01-01','2024-12-31','*','*','*','*');
	
    




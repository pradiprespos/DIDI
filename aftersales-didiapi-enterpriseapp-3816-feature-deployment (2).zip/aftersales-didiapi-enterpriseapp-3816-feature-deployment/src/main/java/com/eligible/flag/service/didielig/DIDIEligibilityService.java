package com.eligible.flag.service.didielig;

import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.bean.DIDIResponse;
import com.eligible.flag.exception.DIDIException;

public interface DIDIEligibilityService {

	public DIDIResponse didiEligibilityService(DIDIRequestBean requestBean) throws DIDIException;
}

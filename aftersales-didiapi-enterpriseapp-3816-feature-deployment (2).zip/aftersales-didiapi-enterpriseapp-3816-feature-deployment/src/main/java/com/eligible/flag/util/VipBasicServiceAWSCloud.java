package com.eligible.flag.util;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.client.RestTemplate;

import com.eligible.flag.exception.DIDIException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VipBasicServiceAWSCloud {

	private static Logger logger = LogManager.getLogger(VipBasicServiceAWSCloud.class);

	RestTemplate restTemplate = new RestTemplate();
     private static final String SUCCESS ="success";//MODIFIED
	public Map<String, Object> getVehicle(String requestVin) throws DIDIException {

		String apiKey = System.getenv("API_KEY");
		String vipPrivateApiURL = System.getenv("VIP_PRIVATE_API_URL");
		String accept = "application/json";
		String contentType = "application/json";
		Date currentDate = new Date(); 
		logger.debug("apiKey {} vipPrivateApiURL {} accept {} contentType {}", apiKey, vipPrivateApiURL, accept, contentType);


		String checkSum = ChecksumConsumer.generateCheckSum(requestVin);
		Map<String, Object> extractedData = new HashMap<>();

		try {
			RequestConfig requestConfig = RequestConfig.custom().build();
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: requestConfig {}", requestConfig);
			// Create an HTTP client with proxy settings
			CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: httpClient {}", httpClient);
			// Create an HTTP POST request
			HttpPost httpPost = new HttpPost(vipPrivateApiURL);
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: httpPost {}", httpPost);
			// Set headers
			httpPost.setHeader("Accept", accept);
			httpPost.setHeader("Content-Type", contentType);
			httpPost.setHeader("X-App-Checksum", checkSum);
			httpPost.setHeader("x-api-key", apiKey);
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: httpClient {}", httpClient);
			// JSON data to be sent in the request body
			String jsonData = "{\n" + "  \"vin\": \"" + requestVin + "\"\n" + "}";
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: httpPost.getHeaders() {}", Arrays.asList(httpPost.getAllHeaders()));

			// Set the JSON data as the request entity
			httpPost.setEntity(new StringEntity(jsonData));
			// Execute the request and get the response
			logger.debug("START : VIP Basic Service Call {}", currentDate.getTime());
			HttpResponse response = httpClient.execute(httpPost);
			logger.debug("END : VIP Basic Service Call {}", currentDate.getTime());
			logger.debug("VipBasicServiceAWSCloud : getVehicle :: response {}", response);

			HttpEntity responseEntity = response.getEntity();
			if (responseEntity != null) {
				logger.debug("VipBasicServiceAWSCloud : getVehicle :: responseEntity {}", responseEntity);

				// Convert the response content to a string
				String responseContent = EntityUtils.toString(responseEntity);
				logger.debug("VipBasicServiceAWSCloud : getVehicle :: responseContent {}", responseContent);
				// Check if the response is successful
				if (isResponseSuccessful(responseContent)) {
					logger.debug("Inside if (isResponseSuccessful(responseContent))");
					ObjectMapper mapper = new ObjectMapper();
					JsonNode rootNode = mapper.readTree(responseContent);
					JsonNode data = rootNode.path(SUCCESS);
					extractedData = new HashMap<>();
					logger.debug("VipBasicServiceAWSCloud : getVehicle :: rootNode {} data {}", rootNode, data);
					if (data.toString().equals("true")) {
						JsonNode dataNode = rootNode.path("message").path("data");
						logger.debug("VipBasicServiceAWSCloud : getVehicle :: dataNode {}", dataNode);
						Iterator<Entry<String, JsonNode>> fields = dataNode.fields();
						logger.debug("VipBasicServiceAWSCloud : getVehicle :: fields {}", fields);

						while (fields.hasNext()) {
							Entry<String, JsonNode> field = fields.next();
							extractedData.put(field.getKey(), field.getValue().toString());
						}
					}
				}
			} else {

				new DIDIExceptionHandler().throwDIDIException(
						"VipBasicServiceAWSCloud : getVehicle :: " + "VIP Basic service generated null response");
			}

			// Ensure the response is properly closed to release resources
			httpClient.close();
		} catch (Exception e) {
			new DIDIExceptionHandler()
					.throwDIDIException("Exception : VipBasicServiceAWSCloud : getVehicle :: " + e.getMessage());
		}
		logger.debug("VipBasicServiceAWSCloud : getVehicle :: extractedData {}", extractedData);

		return extractedData;
	}

	// Check if the response message is successful
	private boolean isResponseSuccessful(String responseContent) throws DIDIException {
		try {
			JSONObject jsonResponse = new JSONObject(responseContent);
			if (jsonResponse.has(SUCCESS) && jsonResponse.getBoolean(SUCCESS)) {
				return true;
			}
		} catch (JSONException e) {
			new DIDIExceptionHandler()
					.throwDIDIException("Exception : VipBasicServiceAWSCloud : getVehicle :: " + e.getMessage());
		}
		return false;
	}

}

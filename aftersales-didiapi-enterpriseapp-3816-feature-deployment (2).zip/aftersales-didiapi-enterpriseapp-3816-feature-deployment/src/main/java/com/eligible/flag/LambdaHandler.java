package com.eligible.flag;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.bean.DIDIResponse;
import com.eligible.flag.service.didielig.DIDIEligibilityServiceImpl;
import com.eligible.flag.validation.didielig.DIDICheckSumValidator;
import com.fca.vip.framework.aws.ApiLambdaHandlerBuilder;

public class LambdaHandler {

	private static Logger logger = LogManager.getLogger(LambdaHandler.class);

	private LambdaHandler() {

	}

	public static RequestStreamHandler createHandler() {
		logger.debug("Entering LambdaHandler : createHandler");
		return ApiLambdaHandlerBuilder.<DIDIRequestBean, DIDIResponse>create()
				.useDefaultConverter(DIDIRequestBean.class)
				.service(new DIDIEligibilityServiceImpl()::didiEligibilityService)
				.validator(DIDICheckSumValidator::validateVIPRequestChecksum).build();	// MODIFIED : PHASE 2
	}

}

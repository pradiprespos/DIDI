package com.eligible.flag.validation.didielig;

import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.eligible.flag.bean.DIDIResponse;



public class DIDIEligibilityRequestInputValidation {
	private   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	private DIDIResponse didiResponse = new DIDIResponse();
	private static Logger logger = LogManager.getLogger(DIDIEligibilityRequestInputValidation.class);

	public int validatevinNumber(String vinNumber) {
                //Removed maxLength, minLength 
		if (null != vinNumber && !vinNumber.isEmpty()) {
			// COMMENTED END : PILOT LAUNCH - VIN VALIDATION
			// ADDED START : PILOT LAUNCH - VIN VALIDATION
			int vinLength = vinNumber.length();
			if (17 == vinLength) {
				didiResponse.setResponseCode("0");
				return 0;

			} else {
				didiResponse.setResponseCode("1");
				return -1;
			}
			// ADDED END : PILOT LAUNCH - VIN VALIDATION
		} else {
			didiResponse.setResponseCode("1");
			return -1;
		}
	}

	// MODIFIED START : PHASE 1+
	public int validateDealerMarket(String dealerMarket) {
		if (dealerMarket.isEmpty()) {
			return 0;
		} else {
			if (1 == dealerMarket.length() && ("U".equalsIgnoreCase(dealerMarket))
					|| ("U".equalsIgnoreCase(dealerMarket)) || ("M".equalsIgnoreCase(dealerMarket))) {

				return 0;

			}
		}
		return -1;
	}
	// MODIFIED END : PHASE 1+

	// START PHASE 1+
	public int validateDealerCode(String dealerCode, int maxLength, int minLength) {

		if (dealerCode != null && !dealerCode.isEmpty()) {
			int dealerCodeLength = dealerCode.length();
			if (dealerCodeLength >= minLength && dealerCodeLength <= maxLength) {
				didiResponse.setResponseCode("0");
				return 0;

			} else {
				didiResponse.setResponseCode("1");
				return -1;
			}
		} else {
			didiResponse.setResponseCode("1");
			return -1;
		}
	}
	// END PHASE 1+

	// MODIFIED START : PHASE 1+
	public int validateDealerZone(String dealerZone, int maxLength, int minLength) {

		if (dealerZone != null && !dealerZone.isEmpty()) {
			int dealerZoneLength = dealerZone.length();
			if (dealerZoneLength >= minLength && dealerZoneLength <= maxLength) {
				didiResponse.setResponseCode("0");
				return 0;

			} else {
				didiResponse.setResponseCode("4");
				return -1;
			}
		}
		return 0;
	}
	// MODIFIED END : PHASE 1+

	public int validateDealerLanguage(String dealerLanguage, int maxLength, int minLength) {

		if (dealerLanguage != null && !dealerLanguage.isEmpty()) {
			int dealCodeLength = dealerLanguage.length();
			if (dealCodeLength >= minLength && dealCodeLength <= maxLength) {
				try {
					Integer.parseInt(dealerLanguage);
					didiResponse.setResponseCode("0");
					return 0;
				} catch (NumberFormatException e) {
					logger.error("DIDIEligibilityRequestInputValidation : validateDealerLanguage :: NumberFormatException {}", e.getMessage());
					didiResponse.setResponseCode("1");
					return -1;
				}
			} else {
				didiResponse.setResponseCode("1");
				return -1;
			}
		}
		return 0;
	}

	public int validateSource(String source, int maxLength, int minLength) {
		if (null != source && !source.isEmpty()) {
			int sourceLength = source.length();
			if ((sourceLength >= minLength && sourceLength <= maxLength)) {
				if (!(source.equalsIgnoreCase("SRLIB") || source.equals("VIPG") || source.equals("VIPD")	// MODIFIED : PHASE 1+
						|| source.equals("VIPW") || source.equals("VIPE") || source.equals("DSDI") )) { // MODIFIED : PHASE 1+
					didiResponse.setResponseCode("1");
					didiResponse.setResponseMessage("VALID SOURCE IS MANDATORY");
					return -1;
				}
			} else {
				didiResponse.setResponseCode("1");
				return -1;
			}
		} else {
			didiResponse.setResponseCode("6");
			return -1;
		}
		return 0;
	}

	// MODIFIED START : PHASE 1+
	public int validateLop(String lop) {
		
		if (lop != null && !lop.isEmpty()) {
			//MODIFIED Extra Condition lop.length() == 2- 
			if (lop.length() == 2 || lop.length() == 4 || lop.length() == 6 || lop.length() == 8) {

				return 0;

			} else {
				return -1;
			}
		} else {
			return -1;
		}

	}
	// MODIFIED END : PHASE 1+

	

    public int isValidDate(String dateStr) {
    	
        if (!isValidFormat(dateStr)) {
            return -1;
        }

        if (!isValidDateRange(dateStr)) {
            return -1;
        }

        return 0;
    }

    private boolean isValidFormat(String dateStr) {
        if (dateStr == null || dateStr.length() != 10) {
            return false;
        }

        for (int i = 0; i < dateStr.length(); i++) {
            if (i == 4 || i == 7) {
                if (dateStr.charAt(i) != '-') {
                    return false;
                }
            } else {
                if (!(dateStr.charAt(i) >= '0' && dateStr.charAt(i) <= '9')) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isValidDateRange(String dateStr) {
        try {
            Date dateLocal = format.parse(dateStr);
            return dateLocal.getTime() <= System.currentTimeMillis();
        } catch (ParseException e) {
            return false;
        }
    }
	// COMMENTED : PHASE 1+

	// START PHASE 1+
	public Map<String, String> getFlagOnLop(String lop) {
		int lopLength = lop.length();
		Map<String, String> responseOnLop = null;
		if (lop.startsWith("18")) {
			responseOnLop = new HashMap<>();
			responseOnLop.put("eligFlag", "N");
			responseOnLop.put("message", "LOP PROVIDED IS A TSB OR RSU LOP");
		} else if (lopLength >= 7 && lop.charAt(6) == '9') {
			responseOnLop = new HashMap<>();
			responseOnLop.put("eligFlag", "N");
			responseOnLop.put("message", "LOP PROVIDED IS A FLASH LOP");
		} 
		return responseOnLop;
	}
	// END PHASE 1+
}

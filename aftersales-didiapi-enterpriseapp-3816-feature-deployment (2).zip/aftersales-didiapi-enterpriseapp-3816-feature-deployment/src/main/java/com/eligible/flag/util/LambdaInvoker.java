package com.eligible.flag.util;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;

public class LambdaInvoker {

	private static final Logger LOG = LoggerFactory.getLogger(LambdaInvoker.class);

	Regions region = Regions.fromName("us-east-1");

	public String invokeLambda(String functionName, String payload) {
		LOG.info("invokeLambda Entry");
		String utf="UTF-8";
		AWSLambdaClientBuilder builder = AWSLambdaClientBuilder.standard().withRegion(region);
		AWSLambda client = builder.build();
		InvokeRequest req = new InvokeRequest().withFunctionName(functionName).withPayload(payload);

		LOG.info("invokeLambda Payload {}", payload);

		InvokeResult result = client.invoke(req);
		ByteBuffer resultPayload = result.getPayload();
		String resultJson = "";
		try {
			resultJson = new String(resultPayload.array(), utf);
		} catch (UnsupportedEncodingException e) {
			LOG.error("UnsupportedEncodingException", e);

		}
		LOG.info("invokeLambda Exit");
		return resultJson;

	}
}

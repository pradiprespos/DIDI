package com.eligible.flag.util;

import java.security.MessageDigest;

import javax.xml.bind.DatatypeConverter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.eligible.flag.exception.DIDIException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ChecksumConsumer {

	private static Logger logger = LogManager.getLogger(ChecksumConsumer.class);

	public static String generateCheckSum(String vinNo) throws DIDIException {

		String checkSum = null;
		ObjectMapper mapper = new ObjectMapper();

		try {
			String vin = vinNo;
			JsonNode rootNode = mapper.createObjectNode();
			((com.fasterxml.jackson.databind.node.ObjectNode) rootNode).put("vin", vin);
			JsonNode node = rootNode;
			String payload = node.toString();
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] digest = messageDigest.digest(payload.getBytes());
			checkSum = DatatypeConverter.printHexBinary(digest);
			logger.debug("ChecksumConsumer : generateCheckSum :: Checksum is: {}", checkSum);

		} catch (Exception e) {
			new DIDIExceptionHandler().throwDIDIException("ChecksumConsumer : generateCheckSum :: " + e.getMessage());
		}
		return checkSum;
	}

	private ChecksumConsumer() {

	}
}

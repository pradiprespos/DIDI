// NEW CLASS : PHASE 2

package com.eligible.flag.validation.didielig;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fca.vip.framework.aws.MalformedRequestException;
import com.fca.vip.framework.security.JwtService;

public class DIDICheckSumValidator {
	 private DIDICheckSumValidator() {
		   
	   }//SONAR MODIFICATION
	private static Logger logger = LogManager.getLogger(DIDICheckSumValidator.class);

	public static final void validateChecksum(String payload, String checksum) throws MalformedRequestException {
		
		String payloadChecksum = JwtService.generateChecksum(payload);
		logger.debug("DIDICheckSumValidator: Checksum should be: {}", payloadChecksum);
		logger.debug("DIDICheckSumValidator: Checksum is: {}", checksum);
		if (!checksum.equalsIgnoreCase(payloadChecksum))
			throw new MalformedRequestException("Invalid: checksum error");
	}

	public static final void validateVIPRequestChecksum(JsonNode req) throws MalformedRequestException {
		String headers="headers";//SONAR MODIFICATION
		if (req == null) {
			throw new MalformedRequestException("Missing request body");
		}
		if (req.get(headers) == null)
			throw new MalformedRequestException("Missing headers field");
		if (req.get(headers).get("checksum") == null)
			throw new MalformedRequestException("Missing checksum field");
		if (req.get("body") == null)
			throw new MalformedRequestException("Missing payload field");
		if (req.get(headers).get("source") == null) {
			throw new MalformedRequestException("Missing source field");
		}
		String payload = req.get("body").toString();
		String source = req.get("body").get("source").toString().trim();
		logger.debug("DIDICheckSumValidator :: validateVIPRequestChecksum : Source = {}", source);
		if (source.contains("SRLIB") || source.contains("DSDI")) {
			logger.debug("Payload as seen by validation method: {}", payload);
			validateChecksum(payload, req.get(headers).get("checksum").textValue());
		}

	}
}

package com.eligible.flag.bean;

public class InsertIntoAuditTableBean {

	private String market;
	private String dealer;
	private String zone;
	private String lang;
	private DIDIResponse didiResponseBean;
	private String vin;
	private String source;
	private String lop;
	private String inServiceDate;
	private String reasonForNonEligibility;

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getDealer() {
		return dealer;
	}

	public void setDealer(String dealer) {
		this.dealer = dealer;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public DIDIResponse getDidiResponseBean() {
		return didiResponseBean;
	}

	public void setDidiResponseBean(DIDIResponse didiResponseBean) {
		this.didiResponseBean = didiResponseBean;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getInServiceDate() {
		return inServiceDate;
	}

	public void setInServiceDate(String inServiceDate) {
		this.inServiceDate = inServiceDate;
	}

	public String getLop() {
		return lop;
	}

	public void setLop(String lop) {
		this.lop = lop;
	}

	public String getReasonForNonEligibility() {
		return reasonForNonEligibility;
	}

	public void setReasonForNonEligibility(String reasonForNonEligibility) {
		this.reasonForNonEligibility = reasonForNonEligibility;
	}

	@Override
	public String toString() {
		return "InsertIntoAuditTableBean [market=" + market + ", dealer=" + dealer + ", zone=" + zone + ", lang=" + lang
				+ ", didiResponseBean=" + didiResponseBean + ", vin=" + vin + ", source=" + source + ", lop=" + lop
				+ ", inServiceDate=" + inServiceDate + ", reasonForNonEligibility=" + reasonForNonEligibility + "]";
	}

}

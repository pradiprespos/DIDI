package com.eligible.flag.bean;

public class DIDISuccessResponse {
	private boolean success;
	private DIDIResponse message;

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public DIDIResponse getMessage() {
		return message;
	}

	public void setMessage(DIDIResponse message) {
		this.message = message;
	}

}

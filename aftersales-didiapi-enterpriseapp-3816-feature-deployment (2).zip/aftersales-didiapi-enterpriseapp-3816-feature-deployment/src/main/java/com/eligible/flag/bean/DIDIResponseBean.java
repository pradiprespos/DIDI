package com.eligible.flag.bean;
 
import java.util.ArrayList;
import java.util.List;
 
public class DIDIResponseBean {
	private String vin;
	private String dealerCode;
	private String dealerZone;
	private String lop;
	private String inServiceDate;
	private String openDate;
	private String responseCode;
	private String responseMessage;
	private String didiEligibilityFlag;
	private String didiMessage;
	// ADDED START : PHASE 1+
	private String misFromTheParm = "99";
	private List<RepairOrderBean> roData = new ArrayList<>();
	private String reasonForNonEligibility;
	// ADDED END : PHASE 1+
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getDealerZone() {
		return dealerZone;
	}
	public void setDealerZone(String dealerZone) {
		this.dealerZone = dealerZone;
	}
	public String getLop() {
		return lop;
	}
	public void setLop(String lop) {
		this.lop = lop;
	}
	public String getInServiceDate() {
		return inServiceDate;
	}
	public void setInServiceDate(String inServiceDate) {
		this.inServiceDate = inServiceDate;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getdidiEligibilityFlag() {
		return didiEligibilityFlag;
	}
	public void setdidiEligibilityFlag(String didiEligibilityFlag) {
		this.didiEligibilityFlag = didiEligibilityFlag;
	}
	public String getdidiMessage() {
		return didiMessage;
	}
	public void setdidiMessage(String dIDIMessage) {
		this.didiMessage = dIDIMessage;
	}
	public String getMisFromTheParm() {
		return misFromTheParm;
	}
	public void setMisFromTheParm(String misFromTheParm) {
		this.misFromTheParm = misFromTheParm;
	}
	public List<RepairOrderBean> getRoData() {
		return roData;
	}
	public void setRoData(List<RepairOrderBean> roData) {
		this.roData = roData;
	}
	public String getReasonForNonEligibility() {
		return reasonForNonEligibility;
	}
	public void setReasonForNonEligibility(String reasonForNonEligibility) {
		this.reasonForNonEligibility = reasonForNonEligibility;
	}
	@Override
	public String toString() {
		return "DIDIResponseBean [vin=" + vin + ", dealerCode=" + dealerCode + ", dealerZone=" + dealerZone + ", lop="
				+ lop + ", inServiceDate=" + inServiceDate + ", openDate=" + openDate + ", responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", dIDIEligibilityFlag=" + didiEligibilityFlag
				+ ", dIDIMessage=" + didiMessage + ", misFromTheParm=" + misFromTheParm + ", roData=" + roData
				+ ", reasonForNonEligibility=" + reasonForNonEligibility + "]";
	}
 
	
 
}
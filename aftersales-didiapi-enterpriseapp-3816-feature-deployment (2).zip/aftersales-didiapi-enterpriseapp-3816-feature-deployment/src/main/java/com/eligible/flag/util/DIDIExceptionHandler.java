package com.eligible.flag.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.eligible.flag.exception.DIDIException;

public class DIDIExceptionHandler {

	private static Logger logger = LogManager.getLogger(DIDIExceptionHandler.class);

	public void throwDIDIException(String message) throws DIDIException {
		logger.error(message);
		throw new DIDIException(message);
	}

}

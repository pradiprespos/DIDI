package com.eligible.flag.bean;

import java.util.ArrayList;
import java.util.List;

public class DIDIResponse {

	private String vin;
	private String dealerMarket;
	private String dealerCode;
	private String dealerZone;
	private String dealerLanguage;
	private String source;
	private String lop;
	private String inServiceDate;
	// COMMENTED : PHASE 1+
	private String didiEligiblityMessage;
	private String didiEligiblityFlag;
	private String responseCode;
	private String responseMessage;
	// ADDED START : PHASE 1+
	private List<RepairOrderBean> roData = new ArrayList<>();
	private String logon;
	// ADDED END : PHASE 1+

	public DIDIResponse() {
		super();
	}


	public Object getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getDealerLanguage() {
		return dealerLanguage;
	}

	public void setDealerLanguage(String dealerLanguage) {
		this.dealerLanguage = dealerLanguage;
	}
	

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getDealerMarket() {
		return dealerMarket;
	}

	public void setDealerMarket(String dealerMarket) {
		this.dealerMarket = dealerMarket;
	}
	public String getDealerZone() {
		return dealerZone;
	}

	public void setDealerZone(String dealerZone) {
		this.dealerZone = dealerZone;
	}

	

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getLop() {
		return lop;
	}

	public void setLop(String lop) {
		this.lop = lop;
	}

	public String getInServiceDate() {
		return inServiceDate;
	}

	public void setInServiceDate(String inServiceDate) {
		this.inServiceDate = inServiceDate;
	}

	// COMMENTED : PHASE 1+

	public String getDidiEligiblityMessage() {
		return this.didiEligiblityMessage;
	}

	public void setDidiEligiblityMessage(String didiEligiblityMessage) {
		this.didiEligiblityMessage = didiEligiblityMessage;
	}

	public String getDidiEligiblityFlag() {
		return this.didiEligiblityFlag;
	}

	public void setDidiEligiblityFlag(String didiEligiblityFlag) {
		this.didiEligiblityFlag = didiEligiblityFlag;
	}

	// ADDED START : PHASE 1+
	public List<RepairOrderBean> getRoData() {
		return roData;
	}

	public void setRoData(List<RepairOrderBean> roData) {
		this.roData = roData;
	}
	
	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}
	// ADDED END : PHASE 1+

	@Override
	public String toString() {
		return "DIDIResponse [ResponseMessage=" + responseMessage + ", vin=" + vin + ", ResponseCode=" + responseCode
				+ ", dealerMarket=" + dealerMarket + ", dealerCode=" + dealerCode + ", dealerZone=" + dealerZone
				+ ", dealerLanguage=" + dealerLanguage + ", source=" + source + ", lop=" + lop + ", inServiceDate="
				+ inServiceDate + ", DidiEligiblityMessage=" + didiEligiblityMessage	// MODIFIED : PHASE 1+
				+ ", DidiEligiblityFlag=" + didiEligiblityFlag + "]";
	}

}

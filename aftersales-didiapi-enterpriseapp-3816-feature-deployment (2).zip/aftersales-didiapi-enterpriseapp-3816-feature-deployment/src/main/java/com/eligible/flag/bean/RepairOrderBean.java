// NEW CLASS : PHASE 1+
package com.eligible.flag.bean;

public class RepairOrderBean {
	private String roNumber;
	private String lineItemNumber;
	private String serviceType;
	private String opsCode;
	private String openDate;
	private String didiEligibilityFlag = "N";
	private String didiMessage = "DIDI IS NOT ELIGIBLE";
	
	@Override
	public String toString() {
		return "RepairOrderBean [roNumber=" + roNumber + ", lineItemNumber=" + lineItemNumber + ", serviceType="
				+ serviceType + ", opsCode=" + opsCode + ", openDate=" + openDate + "]";
	}

	public String getRoNumber() {
		return roNumber;
	}

	public void setRoNumber(String roNumber) {
		this.roNumber = roNumber;
	}

	public String getLineItemNumber() {
		return lineItemNumber;
	}

	public void setLineItemNumber(String lineItemNumber) {
		this.lineItemNumber = lineItemNumber;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getOpsCode() {
		return opsCode;
	}

	public void setOpsCode(String opsCode) {
		this.opsCode = opsCode;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	
	public String getDIDIEligibilityFlag() {
		return didiEligibilityFlag;
	}

	public void setDIDIEligibilityFlag(String didiEligibilityFlag) {
		this.didiEligibilityFlag = didiEligibilityFlag;
	}

	
	public String getDidiMessage() {
		return didiMessage;
	}

	public void setDidiMessage(String didiMessage) {
		this.didiMessage = didiMessage;
	}

	
	
	
	
}

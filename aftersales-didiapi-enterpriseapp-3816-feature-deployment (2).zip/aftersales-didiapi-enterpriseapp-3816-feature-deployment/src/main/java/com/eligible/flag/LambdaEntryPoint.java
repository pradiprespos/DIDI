package com.eligible.flag;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;

public class LambdaEntryPoint {
	private RequestStreamHandler delegate = LambdaHandler.createHandler();
	private static Logger logger = LogManager.getLogger(LambdaEntryPoint.class);

	public void handleRequest(InputStream input, OutputStream output, Context context) throws IOException {
		logger.debug("Entering LambdaEntryPoint : handleRequest input {} output {} context {}", input, output, context);

		delegate.handleRequest(input, output, context);
		logger.debug("Exiting LambdaEntryPoint : handleRequest");
	}
}

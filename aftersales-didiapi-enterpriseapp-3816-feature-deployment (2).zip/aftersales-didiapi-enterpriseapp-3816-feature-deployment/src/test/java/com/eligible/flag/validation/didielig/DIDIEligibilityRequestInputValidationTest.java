package com.eligible.flag.validation.didielig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.junit.Test;

public class DIDIEligibilityRequestInputValidationTest {

    @Test
    public void testValidateVinNumber() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid VIN number
        int result1 = validator.validatevinNumber("12345678901234567");
        assertEquals(0, result1);

        // Test case 2: Invalid VIN number (less than 17 characters)
        int result2 = validator.validatevinNumber("1234567890123456");
        assertEquals(-1, result2);

        // Test case 3: Invalid VIN number (more than 17 characters)
        int result3 = validator.validatevinNumber("123456789012345678");
        assertEquals(-1, result3);

        // Test case 4: Invalid VIN number (null)
        int result4 = validator.validatevinNumber(null);
        assertEquals(-1, result4);

        // Test case 5: Invalid VIN number (empty)
        int result5 = validator.validatevinNumber("");
        assertEquals(-1, result5);
    }

    @Test
    public void testValidateDealerMarket() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid dealer market
        int result1 = validator.validateDealerMarket("U");
        assertEquals(0, result1);

        // Test case 2: Invalid dealer market
        int result2 = validator.validateDealerMarket("X");
        assertEquals(-1, result2);

        // Test case 3: Invalid dealer market (empty)
        int result3 = validator.validateDealerMarket("");
        assertEquals(0, result3);
    }

    @Test
    public void testValidateDealerCode() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid dealer code within the length range
        int result1 = validator.validateDealerCode("DEAL123", 10, 6);
        assertEquals(0, result1);

        // Test case 2: Invalid dealer code (less than minLength)
        int result2 = validator.validateDealerCode("DEAL", 10, 6);
        assertEquals(-1, result2);

        // Test case 3: Invalid dealer code (greater than maxLength)
        int result3 = validator.validateDealerCode(null, 10, 6);
        assertEquals(-1, result3);

        // Test case 4: Invalid dealer code (null)
        int result4 = validator.validateDealerCode(null, 10, 6);
        assertEquals(-1, result4);

        // Test case 5: Invalid dealer code (empty)
        int result5 = validator.validateDealerCode("", 10, 6);
        assertEquals(-1, result5);
    }

    @Test
    public void testValidateDealerZone() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid dealer zone within the length range
        int result1 = validator.validateDealerZone("ZONE123", 10, 6);
        assertEquals(0, result1);

        // Test case 2: Invalid dealer zone (greater than maxLength)
        int result2 = validator.validateDealerZone("ZONE1234567", 10, 6);
        assertEquals(-1, result2);

        // Test case 3: Invalid dealer zone (empty)
        int result3 = validator.validateDealerZone("", 10, 6);
        assertEquals(0, result3);
    }

    @Test
    public void testValidateDealerLanguage() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid dealer language within the length range
        int result1 = validator.validateDealerLanguage("123", 5, 2);
        assertEquals(0, result1);

        // Test case 2: Invalid dealer language (greater than maxLength)
        int result2 = validator.validateDealerLanguage("123456", 5, 2);
        assertEquals(-1, result2);

        // Test case 3: Invalid dealer language (not a number)
        int result3 = validator.validateDealerLanguage("abc", 5, 2);
        assertEquals(-1, result3);

        // Test case 4: Invalid dealer language (empty)
        int result4 = validator.validateDealerLanguage("23675487", 5, 2);
        assertEquals(-1, result4);
        
        int result5 = validator.validateDealerLanguage("", 5, 2);
        assertEquals(0, result5);
    }

    @Test
    public void testValidateSource() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid source within the length range
        int result1 = validator.validateSource("SRLIB", 10, 2);
        assertEquals(0, result1);

        // Test case 2: Invalid source (not in the allowed list)
        int result2 = validator.validateSource("INVALID", 10, 2);
        assertEquals(-1, result2);

        // Test case 3: Invalid source (empty)
        int result3 = validator.validateSource("", 10, 2);
        assertEquals(-1, result3);
        
        int result4 = validator.validateSource("x", 0, 0);
        assertEquals(-1, result4);
    }

    @Test
    public void testValidateLop() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid LOP length (2)
        int result1 = validator.validateLop("12");
        assertEquals(0, result1);

        // Test case 2: Valid LOP length (4)
        int result2 = validator.validateLop("1234");
        assertEquals(0, result2);

        // Test case 3: Invalid LOP length (3)
        int result3 = validator.validateLop("123");
        assertEquals(-1, result3);

        // Test case 4: Invalid LOP length (5)
        int result4 = validator.validateLop("12345");
        assertEquals(-1, result4);

        // Test case 5: Invalid LOP (empty)
        int result5 = validator.validateLop("");
        assertEquals(-1, result5);
    }

    @Test
    public void testIsValidDate() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: Valid date (yyyy-MM-dd)
        int result1 = validator.isValidDate("2022-01-11");
        assertEquals(0, result1);

        // Test case 2: Invalid date (not in the correct format)
        int result2 = validator.isValidDate("11-01-2022");
        assertEquals(-1, result2);

        // Test case 3: Invalid date (empty)
        int result3 = validator.isValidDate("");
        assertEquals(-1, result3);
        
        int result4 = validator.isValidDate("2022011111");
        assertEquals(-1, result4);
        
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
        String strDate = formatter.format(date);
        int result5 = validator.isValidDate(strDate);
        assertEquals(-1, result5);
    }

    @Test
    public void testGetFlagOnLop() {
        DIDIEligibilityRequestInputValidation validator = new DIDIEligibilityRequestInputValidation();

        // Test case 1: LOP starts with "18"
        Map<String, String> result1 = validator.getFlagOnLop("180123");
        assertEquals("N", result1.get("eligFlag"));
        assertEquals("LOP PROVIDED IS A TSB OR RSU LOP", result1.get("message"));

        // Test case 2: LOP ends with '9'
        Map<String, String> result2 = validator.getFlagOnLop("12345796");
        assertEquals("N", result2.get("eligFlag"));
        assertEquals("LOP PROVIDED IS A FLASH LOP", result2.get("message"));

        // Test case 3: Valid LOP
        Map<String, String> result3 = validator.getFlagOnLop("12345678");
        assertNull(result3);
    }
}


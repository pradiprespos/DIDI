package com.eligible.flag.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.exception.DIDIException;
import com.fca.vip.framework.database.DataSourceConfiguration;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ParmServiceTest {

	ParmService parmService;
	
	private DIDIRequestBean didiRequestBean;

	@Mock
	private PreparedStatement stmt;

	@Mock
	private ResultSet rs;
	
	MockedStatic<DataSourceConfiguration> mockDataSource;
	JdbcTemplate jdbcTemplateMock;

	@Before
	public void setup() {
		//MockitoAnnotations.initMocks(this);
		jdbcTemplateMock = Mockito.mock(JdbcTemplate.class);
		mockDataSource = Mockito.mockStatic(DataSourceConfiguration.class);
		mockDataSource.when(() -> DataSourceConfiguration.getJdbcTemplate()).thenReturn(jdbcTemplateMock);
	}	
	
	@After
	public void afterClass() {
		mockDataSource.close();
	}
	
	
//	  @SuppressWarnings("unchecked")
//	  
//	  @Test(expected=NullPointerException.class) public void testParmService()
//	  throws DIDIException, SQLException {
//	  
//	  parmService = new ParmService(); didiRequestBean = new DIDIRequestBean();
//	  Map<String, Object> dataMap = new HashMap<>();
//	  
//	  didiRequestBean.setDealerMarket("US");
//	  didiRequestBean.setDealerCode("ABC123");
//	  didiRequestBean.setDealerZone("Zone1");
//	  didiRequestBean.setDealerLanguage("English");
//	  
//	  dataMap.put("brand", "RRR"); 
//	  dataMap.put("modelYear", "2014");
//	  dataMap.put("bodyStyle", "DS1L98"); 
//	  dataMap.put("engine", "ERB");
//	  dataMap.put("transmission", "DFL"); 
//	  dataMap.put("requestBean",didiRequestBean); 
//	  dataMap.put("lop12", "18"); 
//	  dataMap.put("lop34", "20");
//	  dataMap.put("lop56", "20"); 
//	  dataMap.put("lop78", "22");
//	  
//	  List<Map<String, String>> jdbcResponse = new ArrayList<>();
//	  
//	  stmt.setString(1, didiRequestBean.getDealerMarket()); 
//	  stmt.setString(2, (String) dataMap.get("brand")); 
//	  stmt.setString(3, (String) dataMap.get("modelYear")); 
//	  stmt.setString(4, (String) dataMap.get("bodyStyle")); 
//	  stmt.setString(5, (String) dataMap.get("engine"));
//	  stmt.setString(6, (String) dataMap.get("transmission")); 
//	  stmt.setString(7, didiRequestBean.getDealerCode()); 
//	  stmt.setString(8, didiRequestBean.getDealerZone()); 
//	  stmt.setString(9, didiRequestBean.getDealerLanguage()); 
//	  stmt.setString(10, (String) dataMap.get("lop12")); 
//	  stmt.setString(11, (String) dataMap.get("lop34"));
//	  stmt.setString(12, (String) dataMap.get("lop56")); 
//	  stmt.setString(13, (String) dataMap.get("lop78"));
//	  
//	  when(jdbcTemplateMock.query(Mockito.anyString(), any(PreparedStatementSetter.class), any(ResultSetExtractor.class))).thenReturn(jdbcResponse);
//	  
//	  when(jdbcTemplateMock.query(Mockito.anyString(), any(PreparedStatementSetter.class), any(ResultSetExtractor.class))).thenReturn(jdbcResponse);
//      when(rs.next()).thenReturn(true, false);
//      Mockito.when(jdbcTemplateMock.query(Mockito.anyString(), Mockito.any(PreparedStatementSetter.class),Mockito.any(ResultSetExtractor.class)))
//      .thenAnswer(invocationOnMock -> {
//                    PreparedStatementSetter prepSetter = invocationOnMock.getArgument(1,PreparedStatementSetter.class);
//                    prepSetter.setValues(stmt);
//                    ResultSetExtractor<Object> resultSetExtractor = invocationOnMock.getArgument(2, ResultSetExtractor.class);
//                    resultSetExtractor.extractData(rs);
//                    return resultSetExtractor.extractData(rs);
//              });
//	  
//	  Map<Integer, Map<String, String>> data = parmService.getParmData(dataMap);
//	  System.out.println("Test class"+data); assertNotNull(data);
//	  
//	  }
	 	

	@Test
	public void removeDoubleCodeFromStartAndEnd() throws DIDIException {
		parmService = new ParmService();
		String var =parmService.removeDoubleCodeFromStartAndEnd("");
		assertEquals("",var);
	}
	
	
	@Test
	public void testRankLogic() throws DIDIException {
		parmService = new ParmService();
		List<Map<String, String>> data = new ArrayList<>();
		Map<String, String> dataMap = new HashMap<>(); 
	  	dataMap.put("C_MKT", "M");
		dataMap.put("C_BRND", "DODGE");
		dataMap.put("I_MOD_YR", "2023");
		dataMap.put("C_BODY_MODEL", "MPJP74");
		dataMap.put("C_ENGINE_SC", "EZL");
		dataMap.put("C_TRANS_SC", "DFT");
		dataMap.put("C_DLR", "60009");
		dataMap.put("C_ZONE", "66");
		dataMap.put("C_LANG", "010");
		dataMap.put("Q_MIS", "3");
		dataMap.put("LOP1_2", "18");
		dataMap.put("LOP3_4", "U4");		
		dataMap.put("LOP5_6", "91"); 
		dataMap.put("LOP7_8", "82");
		
		Map<String, String> dataMap1 = new HashMap<>(); 
	  	dataMap1.put("C_MKT", "U");
		dataMap1.put("C_BRND", "DODGE");
		dataMap1.put("I_MOD_YR", "2023");
		dataMap1.put("C_BODY_MODEL", "MPJP74");
		dataMap1.put("C_ENGINE_SC", "EZL");
		dataMap1.put("C_TRANS_SC", "DFT");
		dataMap1.put("C_DLR", "60009");
		dataMap1.put("C_ZONE", "66");
		dataMap1.put("C_LANG", "010");
		dataMap1.put("Q_MIS", "3");
		dataMap1.put("LOP1_2", "18");
		dataMap1.put("LOP3_4", "U4");		
		dataMap1.put("LOP5_6", "91"); 
		dataMap1.put("LOP7_8", "82");
		
		data.add(dataMap);
		data.add(dataMap1);
		
		Map<Integer, Map<String, String>> result = parmService.rankLogic(data);
		assertNotNull(result);
		
	}
}

package com.eligible.flag.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class DIDIExceptionTest {

    @Test
    public void testDIDIException() {
        // Create a DIDIException instance with a custom message
        String errorMessage = "Test DIDI Exception";
        DIDIException didiException = new DIDIException(errorMessage);

        // Verify that the exception message is set correctly
        assertEquals(errorMessage, didiException.getMessage());

        // Verify the toString method
        String expectedToString = "DIDIException [message=" + errorMessage + "]";
        assertEquals(expectedToString, didiException.toString());
    }
}
package com.eligible.flag.bean;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.Before;
import org.junit.Test;
public class DIDIResponseBeanTest { 
    private DIDIResponseBean didiResponseBean;
    List<RepairOrderBean> roData = new ArrayList<>();
    @Before
    public void setUp() {
        // Create an instance of DIDIResponseBean for testing
        didiResponseBean = new DIDIResponseBean();
        didiResponseBean.setVin("123456");
        didiResponseBean.setDealerCode("ABC123");
        didiResponseBean.setDealerZone("Zone1");
        didiResponseBean.setLop("L123");
        didiResponseBean.setInServiceDate("2022-01-01");
        didiResponseBean.setOpenDate("2022-01-02");
        didiResponseBean.setResponseCode("200");
        didiResponseBean.setResponseMessage("Success");
        didiResponseBean.setdidiEligibilityFlag("Y");
        didiResponseBean.setdidiMessage("Eligible");
        didiResponseBean.setMisFromTheParm("99");
        didiResponseBean.setReasonForNonEligibility("Not eligible due to reason XYZ");
        didiResponseBean.setRoData(roData);
    }
    @Test
    public void testGetters() {
        assertEquals("123456", didiResponseBean.getVin());
        assertEquals("ABC123", didiResponseBean.getDealerCode());
        assertEquals("Zone1", didiResponseBean.getDealerZone());
        assertEquals("L123", didiResponseBean.getLop());
        assertEquals("2022-01-01", didiResponseBean.getInServiceDate());
        assertEquals("2022-01-02", didiResponseBean.getOpenDate());
        assertEquals("200", didiResponseBean.getResponseCode());
        assertEquals("Success", didiResponseBean.getResponseMessage());
        assertEquals("Y", didiResponseBean.getdidiEligibilityFlag());
        assertEquals("Eligible", didiResponseBean.getdidiMessage());
        assertEquals("99", didiResponseBean.getMisFromTheParm());
        assertEquals("Not eligible due to reason XYZ", didiResponseBean.getReasonForNonEligibility());
        assertEquals(roData,didiResponseBean.getRoData());
        assertNotNull(didiResponseBean.toString());
    }
    @Test
    public void testSetters() {
        // Update values using setters
        didiResponseBean.setVin("654321");
        didiResponseBean.setDealerCode("XYZ789");
        didiResponseBean.setDealerZone("Zone2");
        didiResponseBean.setLop("L456");
        didiResponseBean.setInServiceDate("2023-01-01");
        didiResponseBean.setOpenDate("2023-01-02");
        didiResponseBean.setResponseCode("400");
        didiResponseBean.setResponseMessage("Failure");
        didiResponseBean.setdidiEligibilityFlag("N");
        didiResponseBean.setdidiMessage("Not Eligible");
        didiResponseBean.setMisFromTheParm("88");
        didiResponseBean.setReasonForNonEligibility("Not eligible due to reason ABC");
        // Verify the changes
        assertEquals("654321", didiResponseBean.getVin());
        assertEquals("XYZ789", didiResponseBean.getDealerCode());
        assertEquals("Zone2", didiResponseBean.getDealerZone());
        assertEquals("L456", didiResponseBean.getLop());
        assertEquals("2023-01-01", didiResponseBean.getInServiceDate());
        assertEquals("2023-01-02", didiResponseBean.getOpenDate());
        assertEquals("400", didiResponseBean.getResponseCode());
        assertEquals("Failure", didiResponseBean.getResponseMessage());
        assertEquals("N", didiResponseBean.getdidiEligibilityFlag());
        assertEquals("Not Eligible", didiResponseBean.getdidiMessage());
        assertEquals("88", didiResponseBean.getMisFromTheParm());
        assertEquals("Not eligible due to reason ABC", didiResponseBean.getReasonForNonEligibility());
    }
}

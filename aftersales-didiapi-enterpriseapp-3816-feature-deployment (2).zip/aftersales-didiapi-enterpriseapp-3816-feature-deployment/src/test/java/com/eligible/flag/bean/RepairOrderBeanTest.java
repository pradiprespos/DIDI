package com.eligible.flag.bean;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RepairOrderBeanTest {

    @Test
    public void testGetRoNumber() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setRoNumber("123");
        assertEquals("123", repairOrderBean.getRoNumber());
    }

    @Test
    public void testGetLineItemNumber() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setLineItemNumber("456");
        assertEquals("456", repairOrderBean.getLineItemNumber());
    }

    @Test
    public void testGetServiceType() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setServiceType("ServiceA");
        assertEquals("ServiceA", repairOrderBean.getServiceType());
    }

    @Test
    public void testGetOpsCode() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setOpsCode("OP123");
        assertEquals("OP123", repairOrderBean.getOpsCode());
    }

    @Test
    public void testGetOpenDate() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setOpenDate("2024-01-10");
        assertEquals("2024-01-10", repairOrderBean.getOpenDate());
    }

    @Test
    public void testGetDIDIEligibilityFlag() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setDIDIEligibilityFlag("Y");
        assertEquals("Y", repairOrderBean.getDIDIEligibilityFlag());
    }

    @Test
    public void testGetDidiMessage() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setDidiMessage("DIDI is eligible");
        assertEquals("DIDI is eligible", repairOrderBean.getDidiMessage());
    }

    @Test
    public void testToString() {
        RepairOrderBean repairOrderBean = new RepairOrderBean();
        repairOrderBean.setRoNumber("123");
        repairOrderBean.setLineItemNumber("456");
        repairOrderBean.setServiceType("ServiceA");
        repairOrderBean.setOpsCode("OP123");
        repairOrderBean.setOpenDate("2024-01-10");

        String expectedToString = "RepairOrderBean [roNumber=123, lineItemNumber=456, serviceType=ServiceA, opsCode=OP123, openDate=2024-01-10]";
        assertEquals(expectedToString, repairOrderBean.toString());
    }
}

package com.eligible.flag.bean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class DIDISuccessResponseTest {

    private DIDISuccessResponse didiSuccessResponse;

    @Before
    public void setUp() {
        // Sample data for testing
        DIDIResponse didiResponse = new DIDIResponse();
        didiResponse.setResponseMessage("Success");
        didiResponse.setVin("123456");
        didiResponse.setResponseCode("200");
        didiResponse.setDealerMarket("US");
        didiResponse.setDealerCode("ABC123");
        didiResponse.setDealerZone("East");
        didiResponse.setDealerLanguage("English");
        didiResponse.setSource("Web");
        didiResponse.setLop("123");
        didiResponse.setInServiceDate("2022-01-01");
        didiResponse.setDidiEligiblityMessage("Eligible");
        didiResponse.setDidiEligiblityFlag("Y");

        didiSuccessResponse = new DIDISuccessResponse();
        didiSuccessResponse.setSuccess(true);
        didiSuccessResponse.setMessage(didiResponse);
    }

    @Test
    public void testGetters() {
        assertEquals(true, didiSuccessResponse.getSuccess());

        DIDIResponse message = didiSuccessResponse.getMessage();
        assertNotNull(message);
        assertEquals("Success", message.getResponseMessage());
        assertEquals("123456", message.getVin());
        assertEquals("200", message.getResponseCode());
        assertEquals("US", message.getDealerMarket());
        assertEquals("ABC123", message.getDealerCode());
        assertEquals("East", message.getDealerZone());
        assertEquals("English", message.getDealerLanguage());
        assertEquals("Web", message.getSource());
        assertEquals("123", message.getLop());
        assertEquals("2022-01-01", message.getInServiceDate());
        assertEquals("Eligible", message.getDidiEligiblityMessage());
        assertEquals("Y", message.getDidiEligiblityFlag());
    }

    @Test
    public void testSetters() {
        // Set new values using setters
        didiSuccessResponse.setSuccess(false);

        DIDIResponse newDIDIResponse = new DIDIResponse();
        newDIDIResponse.setResponseMessage("Failed");
        newDIDIResponse.setVin("654321");
        newDIDIResponse.setResponseCode("404");
        newDIDIResponse.setDealerMarket("EU");
        newDIDIResponse.setDealerCode("XYZ789");
        newDIDIResponse.setDealerZone("West");
        newDIDIResponse.setDealerLanguage("French");
        newDIDIResponse.setSource("Mobile");
        newDIDIResponse.setLop("456");
        newDIDIResponse.setInServiceDate("2022-02-01");
        newDIDIResponse.setDidiEligiblityMessage("Not Eligible");
        newDIDIResponse.setDidiEligiblityFlag("N");

        didiSuccessResponse.setMessage(newDIDIResponse);

        // Verify the changes
        assertEquals(false, didiSuccessResponse.getSuccess());

        DIDIResponse updatedMessage = didiSuccessResponse.getMessage();
        assertNotNull(updatedMessage);
        assertEquals("Failed", updatedMessage.getResponseMessage());
        assertEquals("654321", updatedMessage.getVin());
        assertEquals("404", updatedMessage.getResponseCode());
        assertEquals("EU", updatedMessage.getDealerMarket());
        assertEquals("XYZ789", updatedMessage.getDealerCode());
        assertEquals("West", updatedMessage.getDealerZone());
        assertEquals("French", updatedMessage.getDealerLanguage());
        assertEquals("Mobile", updatedMessage.getSource());
        assertEquals("456", updatedMessage.getLop());
        assertEquals("2022-02-01", updatedMessage.getInServiceDate());
        assertEquals("Not Eligible", updatedMessage.getDidiEligiblityMessage());
        assertEquals("N", updatedMessage.getDidiEligiblityFlag());
    }
}

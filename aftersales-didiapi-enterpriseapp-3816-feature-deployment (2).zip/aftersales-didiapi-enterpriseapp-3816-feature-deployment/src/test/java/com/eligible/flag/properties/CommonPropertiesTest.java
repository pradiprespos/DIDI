package com.eligible.flag.properties;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.eligible.flag.bean.DIDIRequestBean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Before;


public class CommonPropertiesTest {


    private CommonProperties  commonProperties = new CommonProperties();
   
    @Test
    public void testCommonPropertiesValues() {
        assertNotNull(commonProperties);
       
    	commonProperties.setApikey("idnumber");
    	commonProperties.setAcceptType("yes");
    	commonProperties.setUrl("infra.fca.com");
    	commonProperties.setContentType("didi Api");
       
        assertEquals("idnumber", commonProperties.getApikey());
        assertEquals("infra.fca.com", commonProperties.getUrl());
        assertEquals("yes", commonProperties.getAcceptType());
        assertEquals("didi Api", commonProperties.getContentType());
        assertEquals(commonProperties.toString(),commonProperties.toString());
    }
    
}

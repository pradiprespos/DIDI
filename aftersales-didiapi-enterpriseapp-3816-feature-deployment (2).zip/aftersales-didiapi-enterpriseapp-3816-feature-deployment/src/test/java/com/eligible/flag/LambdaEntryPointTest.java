package com.eligible.flag;

import static org.junit.Assert.assertNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import com.amazonaws.services.lambda.runtime.Context;
import com.fca.vip.framework.database.DataSourceConfiguration;


@RunWith(MockitoJUnitRunner.class)
public class LambdaEntryPointTest {
 
    @Mock
    private LambdaHandler lambdaHandlerMock;
 
    @Mock
    private Context contextMock;
 
    private LambdaEntryPoint lambdaEntryPoint;
    
    @Mock
	JdbcTemplate jdbcTemplate;
 
    @Before
    public void setup() {
       // MockitoAnnotations.initMocks(this);
        MockedStatic<DataSourceConfiguration> mockDataSource;
		mockDataSource = Mockito.mockStatic(DataSourceConfiguration.class);
		mockDataSource.when(() -> DataSourceConfiguration.getJdbcTemplate()).thenReturn(jdbcTemplate);
    }
 
    @Test(expected=RuntimeException.class)
    public void handleRequest_ValidInput_CallsLambdaHandler() throws IOException {
    	lambdaEntryPoint = new LambdaEntryPoint();
        InputStream input = new ByteArrayInputStream("TestInput".getBytes());
        OutputStream output = new ByteArrayOutputStream();
 
        lambdaEntryPoint.handleRequest(input, output, contextMock);
        assertNull(null);
 
    }
}

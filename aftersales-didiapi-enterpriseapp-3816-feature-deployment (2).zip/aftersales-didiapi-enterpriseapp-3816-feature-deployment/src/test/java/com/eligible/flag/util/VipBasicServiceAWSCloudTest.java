package com.eligible.flag.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Map;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import uk.org.webcompere.systemstubs.rules.EnvironmentVariablesRule;
 
public class VipBasicServiceAWSCloudTest {
 
    @InjectMocks
    @Spy
    private VipBasicServiceAWSCloud vipBasicServiceAWSCloud;
 
    @Rule
	public EnvironmentVariablesRule environmentVariablesRule = new EnvironmentVariablesRule()
			.set("API_KEY", "cpSeUxdqaH3bjfGxNtMGp7fSl94bn2t723dI9Z4i")
			.set("VIP_PRIVATE_API_URL", "https://0jy7u2ebe7-vpce-0081b0b91b6b3f2b3.execute-api.us-east-1.amazonaws.com/test/getVehicle");
    
    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        //System.setProperty("API_KEY", "cpSeUxdqaH3bjfGxNtMGp7fSl94bn2t723dI9Z4i");      
       // System.setProperty("VIP_PRIVATE_API_URL", "https://0jy7u2ebe7-vpce-0081b0b91b6b3f2b3.execute-api.us-east-1.amazonaws.com/test/getVehicle");
    }
 
    @Test
    public void testGetVehicle() throws Exception { 
        Map<String, Object> map =  vipBasicServiceAWSCloud.getVehicle("1C6RR6KG8ES221908");
        assertNotNull(map);
    }
    
    @Test
    public void testGetVehicleException() throws Exception { 
        Map<String, Object> map =  vipBasicServiceAWSCloud.getVehicle("vinnumber");
        assertNotNull(map);
    }
    
    @Test
    public void testGetVehicleException1() throws Exception { 
    	System.setProperty("VIP_PRIVATE_API_URL", "");
        Map<String, Object> map =  vipBasicServiceAWSCloud.getVehicle("vinnumber");
        assertNotNull(map);
    }
}
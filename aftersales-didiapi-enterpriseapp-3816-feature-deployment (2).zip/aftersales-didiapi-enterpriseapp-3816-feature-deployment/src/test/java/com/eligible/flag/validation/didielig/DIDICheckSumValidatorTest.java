package com.eligible.flag.validation.didielig;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fca.vip.framework.aws.MalformedRequestException;
 
public class DIDICheckSumValidatorTest {
 
    @Test(expected = MalformedRequestException.class)
    public void testValidateChecksumInvalid() throws MalformedRequestException {
        String payload = "testPayload";
        String invalidChecksum = "invalidChecksum";
 
        DIDICheckSumValidator.validateChecksum(payload, invalidChecksum);
    }
 
	
	 @Test(expected = MalformedRequestException.class) 
	 public void testValidateVIPRequestChecksumMissingHeaders() throws MalformedRequestException 
	 { 
		 
		 Map<String, String> myMap = new HashMap<>();
		 myMap.put("headers", null);
		 ObjectMapper mapper = new ObjectMapper();
		 JsonNode jsonNodeMap = mapper.convertValue(myMap, JsonNode.class);
		 
		 DIDICheckSumValidator.validateVIPRequestChecksum(jsonNodeMap);	 
	 }
	 
	 @Test(expected = MalformedRequestException.class) 
	 public void testValidateVIPRequestChecksumMissingBody() throws MalformedRequestException 
	 { 
		 
		 Map<String, String> myMap = new HashMap<>();
		 myMap.put("body", null);
		 ObjectMapper mapper = new ObjectMapper();
		 JsonNode jsonNodeMap = mapper.convertValue(myMap, JsonNode.class);
		 
		 DIDICheckSumValidator.validateVIPRequestChecksum(jsonNodeMap);	 
	 }
	 
	 @Test
	 public void testVIPREQ() throws MalformedRequestException
	 {
		 String payload = "testPayload";
	     String checksumm = "9E337AC90FBB1EB70211EF04E78EC83FB06E3CA646C8F783C8DD453517C82B05";
		 Map<String,Map<String, String>> myMap = new HashMap<>();
		 Map<String, String> source = new HashMap<>();
		 source.put("source", "SRLIB");
		 Map<String,String> checksum = new HashMap<>();
		 checksum.put("checksum", checksumm);
		 checksum.put("source", "SRLIB");
		 myMap.put("body", source);
		 myMap.put("headers", checksum);
		 
		 ObjectMapper mapper = new ObjectMapper();
		 JsonNode jsonNodeMap = mapper.convertValue(myMap, JsonNode.class);
		 DIDICheckSumValidator.validateVIPRequestChecksum(jsonNodeMap);	
	 }
	 
	 @Test(expected = MalformedRequestException.class)
	 public void testVIPReqNull() throws MalformedRequestException {
		 JsonNode req = null;
		 DIDICheckSumValidator.validateVIPRequestChecksum(req);	
	 }
	 
	 @Test(expected = MalformedRequestException.class)
	 public void testVIPReqbodyNull() throws MalformedRequestException {
		 String checksumm = "9E337AC90FBB1EB70211EF04E78EC83FB06E3CA646C8F783C8DD453517C82B05";
		 Map<String,Map<String, String>> myMap = new HashMap<>();
		 Map<String,String> checksum = new HashMap<>();
		 checksum.put("checksum", checksumm);
		 checksum.put("source", "SRLIB");
		 myMap.put("headers", checksum);
		 ObjectMapper mapper = new ObjectMapper();
		 JsonNode jsonNodeMap = mapper.convertValue(myMap, JsonNode.class);
		 DIDICheckSumValidator.validateVIPRequestChecksum(jsonNodeMap);
	 }
	 
}
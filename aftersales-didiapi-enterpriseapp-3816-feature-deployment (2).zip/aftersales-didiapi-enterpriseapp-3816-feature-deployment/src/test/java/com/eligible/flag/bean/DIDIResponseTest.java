package com.eligible.flag.bean;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
 
import org.junit.Before;
import org.junit.Test;
 
public class DIDIResponseTest {
 
    private DIDIResponse didiResponse;
	List<RepairOrderBean> roData = new ArrayList<>();
    @Before
    public void setUp() {
    	
        // Create an instance of DIDIResponse for testing
        didiResponse = new DIDIResponse();
        didiResponse.setVin("123456");
        didiResponse.setDealerMarket("US");
        didiResponse.setDealerCode("ABC123");
        didiResponse.setDealerZone("Zone1");
        didiResponse.setDealerLanguage("English");
        didiResponse.setLop("L123");
        didiResponse.setSource("Web");
        didiResponse.setInServiceDate("2022-01-01");
        didiResponse.setResponseMessage("Success");
        didiResponse.setResponseCode("200");
        didiResponse.setDidiEligiblityMessage("Eligible");
        didiResponse.setDidiEligiblityFlag("Y");
        didiResponse.setLogon("user123");
        didiResponse.setRoData(roData);
      //  DIDIResponse didi=new DIDIResponse("Success",didiResponse.getVin(),didiResponse.getResponseCode(),didiResponse.getDealerMarket(),didiResponse.getDealerCode(),didiResponse.getDealerZone(),didiResponse.getDealerLanguage(),didiResponse.getSource(),didiResponse.getLop(),didiResponse.getInServiceDate(),didiResponse.getDidiEligiblityMessage(),didiResponse.getDidiEligiblityFlag(),didiResponse.getRoData(),didiResponse.getLogon());
    }
 
    @Test
    public void testGetters() {
        assertEquals("123456", didiResponse.getVin());
        assertEquals("US", didiResponse.getDealerMarket());
        assertEquals("ABC123", didiResponse.getDealerCode());
        assertEquals("Zone1", didiResponse.getDealerZone());
        assertEquals("English", didiResponse.getDealerLanguage());
        assertEquals("L123", didiResponse.getLop());
        assertEquals("Web", didiResponse.getSource());
        assertEquals("2022-01-01", didiResponse.getInServiceDate());
        assertEquals("Success", didiResponse.getResponseMessage());
        assertEquals("200", didiResponse.getResponseCode());
        assertEquals("Eligible", didiResponse.getDidiEligiblityMessage());
        assertEquals("Y", didiResponse.getDidiEligiblityFlag());
        assertEquals("user123", didiResponse.getLogon());
        assertEquals(roData,didiResponse.getRoData());
        assertNotNull(didiResponse.toString());
        
    }
 
    @Test
    public void testSetters() {
        // Update values using setters
        didiResponse.setVin("654321");
        didiResponse.setDealerMarket("Canada");
        didiResponse.setDealerCode("XYZ789");
        didiResponse.setDealerZone("Zone2");
        didiResponse.setDealerLanguage("French");
        didiResponse.setLop("L456");
        didiResponse.setSource("Mobile");
        didiResponse.setInServiceDate("2023-01-01");
        didiResponse.setResponseMessage("Failure");
        didiResponse.setResponseCode("400");
        didiResponse.setDidiEligiblityMessage("Not Eligible");
        didiResponse.setDidiEligiblityFlag("N");
        didiResponse.setLogon("user456");
 
        // Verify the changes
        assertEquals("654321", didiResponse.getVin());
        assertEquals("Canada", didiResponse.getDealerMarket());
        assertEquals("XYZ789", didiResponse.getDealerCode());
        assertEquals("Zone2", didiResponse.getDealerZone());
        assertEquals("French", didiResponse.getDealerLanguage());
        assertEquals("L456", didiResponse.getLop());
        assertEquals("Mobile", didiResponse.getSource());
        assertEquals("2023-01-01", didiResponse.getInServiceDate());
        assertEquals("Failure", didiResponse.getResponseMessage());
        assertEquals("400", didiResponse.getResponseCode());
        assertEquals("Not Eligible", didiResponse.getDidiEligiblityMessage());
        assertEquals("N", didiResponse.getDidiEligiblityFlag());
        assertEquals("user456", didiResponse.getLogon());
    }
}
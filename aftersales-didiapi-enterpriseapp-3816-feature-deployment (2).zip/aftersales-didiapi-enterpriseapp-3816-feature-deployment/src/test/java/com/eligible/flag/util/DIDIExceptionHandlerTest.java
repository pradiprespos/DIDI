package com.eligible.flag.util;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.eligible.flag.exception.DIDIException;

public class DIDIExceptionHandlerTest {

    @Test
    public void testThrowDIDIException() {
        DIDIExceptionHandler didiExceptionHandler = new DIDIExceptionHandler();

        String errorMessage = "Test DIDIException message";

        try {
            didiExceptionHandler.throwDIDIException(errorMessage);
        } catch (DIDIException e) {
            assertEquals(errorMessage, e.getMessage());
        }
    }
}

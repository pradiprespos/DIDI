package com.eligible.flag.bean;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
 
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
public class DIDIRequestBeanTest {
    private DIDIRequestBean didiRequestBean;
    List<RepairOrderBean> roData = new ArrayList<>();
    @Before
    public void setUp() {
        // Create an instance of DIDIRequestBean for testing
        didiRequestBean = new DIDIRequestBean();
        didiRequestBean.setVin("123456");
        didiRequestBean.setDealerMarket("US");
        didiRequestBean.setDealerCode("ABC123");
        didiRequestBean.setDealerZone("Zone1");
        didiRequestBean.setDealerLanguage("English");
        didiRequestBean.setLop("L123");
        didiRequestBean.setSource("Web");
        didiRequestBean.setInServiceDate("2022-01-01");
        didiRequestBean.setLogon("user123");
        didiRequestBean.setRoData(roData);
    }
    @Test
    public void testGetters() {
        assertEquals("123456", didiRequestBean.getVin());
        assertEquals("US", didiRequestBean.getDealerMarket());
        assertEquals("ABC123", didiRequestBean.getDealerCode());
        assertEquals("Zone1", didiRequestBean.getDealerZone());
        assertEquals("English", didiRequestBean.getDealerLanguage());
        assertEquals("L123", didiRequestBean.getLop());
        assertEquals("Web", didiRequestBean.getSource());
        assertEquals("2022-01-01", didiRequestBean.getInServiceDate());
        assertEquals("user123", didiRequestBean.getLogon());
        assertEquals(roData,didiRequestBean.getRoData());
        assertNotNull(didiRequestBean.toString());
    }
    @Test
    public void testSetters() {
        // Update values using setters
        didiRequestBean.setVin("654321");
        didiRequestBean.setDealerMarket("Canada");
        didiRequestBean.setDealerCode("XYZ789");
        didiRequestBean.setDealerZone("Zone2");
        didiRequestBean.setDealerLanguage("French");
        didiRequestBean.setLop("L456");
        didiRequestBean.setSource("Mobile");
        didiRequestBean.setInServiceDate("2023-01-01");
        didiRequestBean.setLogon("user456");
        // Verify the changes
        assertEquals("654321", didiRequestBean.getVin());
        assertEquals("Canada", didiRequestBean.getDealerMarket());
        assertEquals("XYZ789", didiRequestBean.getDealerCode());
        assertEquals("Zone2", didiRequestBean.getDealerZone());
        assertEquals("French", didiRequestBean.getDealerLanguage());
        assertEquals("L456", didiRequestBean.getLop());
        assertEquals("Mobile", didiRequestBean.getSource());
        assertEquals("2023-01-01", didiRequestBean.getInServiceDate());
        assertEquals("user456", didiRequestBean.getLogon());
    }
}
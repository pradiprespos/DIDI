package com.eligible.flag.service.didielig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.bean.DIDIResponse;
import com.eligible.flag.bean.DIDIResponseBean;
import com.eligible.flag.bean.RepairOrderBean;
import com.eligible.flag.exception.DIDIException;
import com.fca.vip.framework.database.DataSourceConfiguration;

import uk.org.webcompere.systemstubs.rules.EnvironmentVariablesRule;

@RunWith(MockitoJUnitRunner.class)
public class DIDIEligibilityServiceImplTest {

	//@InjectMocks
	DIDIEligibilityServiceImpl serviceImpl;

	@Mock
	JdbcTemplate jdbcTemplate;
	
	@Mock
	private PreparedStatement stmt;
	
	@Mock
	ResultSetMetaData metaData;
	
	@Mock
	PreparedStatement ps;
	
	@Captor
	ArgumentCaptor<PreparedStatementSetter> setterArgumentCaptor;
	
	@Mock
	ResultSet rs;
	
	@Mock
	ResultSetExtractor rsextract;
	
	MockedStatic<DataSourceConfiguration> mockDataSource;
	
	@Rule
	public EnvironmentVariablesRule environmentVariablesRule = new EnvironmentVariablesRule()
			.set("API_KEY", "cpSeUxdqaH3bjfGxNtMGp7fSl94bn2t723dI9Z4i")
			.set("VIP_PRIVATE_API_URL", "https://0jy7u2ebe7-vpce-0081b0b91b6b3f2b3.execute-api.us-east-1.amazonaws.com/test/getVehicle");
	
	DIDIRequestBean requestBean = new DIDIRequestBean();
	DIDIResponseBean responseBean = new DIDIResponseBean(); 
	
	RepairOrderBean orderBean = new RepairOrderBean();
	
	@Before
	public void setup() {
		//MockitoAnnotations.initMocks(this);
		jdbcTemplate = Mockito.mock(JdbcTemplate.class);
		
		
		
		  mockDataSource = Mockito.mockStatic(DataSourceConfiguration.class);
		  mockDataSource.when(() ->
		  DataSourceConfiguration.getJdbcTemplate()).thenReturn(jdbcTemplate);
		 
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerLanguage("010");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setInServiceDate("2024-01-13");
		requestBean.setLogon("t0020zb");
		requestBean.setLop("18202022");
		requestBean.setSource("SRLIB");
		
		RepairOrderBean orderBean = new RepairOrderBean();
		orderBean.setDIDIEligibilityFlag("Y");
		orderBean.setDidiMessage("test");
		orderBean.setLineItemNumber("1");
		orderBean.setOpenDate("2023-10-20");
		orderBean.setOpsCode("080801PC");
		orderBean.setRoNumber("ro-04-jan-1");
		orderBean.setServiceType("F");
	}
	
	@After
	public void afterClass() {
		mockDataSource.close();
	}

	@Test
	public void testdidiEligibilityService() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		
		List<RepairOrderBean> list = new ArrayList<>();
		list.add(orderBean);
		
		requestBean.setRoData(list);

		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response);

	}
	
	@Test(expected=NullPointerException.class)
	public void testdidiEligibilityService1() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean = null;
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response);
	}
	
	@Test(expected=NullPointerException.class)
	public void testdidiEligibilityService2() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setLop("2435");
		orderBean.setOpsCode("0801PC");
		orderBean.setServiceType("R");
		
		List<RepairOrderBean> list = new ArrayList<>();
		list.add(orderBean);
		
		requestBean.setRoData(list);

		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response);
	}
	
	@Test(expected=NullPointerException.class)
	public void testdidiEligibilityService3() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setLop("2435");
		orderBean.setOpsCode("0801PC");
		orderBean.setServiceType("RC");
		
		List<RepairOrderBean> list = new ArrayList<>();
		list.add(orderBean);
		
		requestBean.setRoData(list);

		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response);

	}
	
	@Test
	public void testdidiEligibilityServiceElseVIN() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES22190");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testdidiEligibilityServiceElseMarket() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerMarket("C");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testdidiEligibilityServiceOpsCode() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		orderBean.setOpsCode("");
		requestBean.setLop("23202092");
		DIDIResponse response1 = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response1);
	}
	
	@Test(expected=NullPointerException.class)
	public void testdidiEligibilityServiceOpsCodeError(){
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		orderBean.setOpsCode("");
		requestBean.setLop("");
		DIDIResponse response2 = serviceImpl.didiEligibilityService(requestBean);
		assertNotNull(response2);
		
	}
	
	@Test
	public void testdidiEligibilityServiceElseDealerCode() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerMarket("U");
		requestBean.setDealerCode("1234");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testdidiEligibilityServiceElseDealerZone() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("7");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	
	@Test
	public void testdidiEligibilityServiceElseDealerLang() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("01");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testdidiEligibilityServiceElseSource() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("010");
		requestBean.setSource("abcd");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	
	@Test
	public void testdidiEligibilityServiceElseLop() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("010");
		requestBean.setSource("SRLIB");
		requestBean.setLop("12344");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testdidiEligibilityServiceElseInServiceDate() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("010");
		requestBean.setSource("SRLIB");
		requestBean.setLop("18020202");
		requestBean.setInServiceDate("2024-01");
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);	
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testdidiEligibilityServiceElseByVin() throws SQLException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerMarket("U");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("010");
		requestBean.setSource("SRLIB");
		requestBean.setLop("18020202");
		requestBean.setInServiceDate("");
		
//		when(rs.next()).thenReturn(true, false);
//		when(rs.getString(anyString())).thenReturn("123456");
//		when(rs.getString("I_PRTITN")).thenReturn("12");
//		when(rs.getString("L_VHCL_SOLD")).thenReturn("Y");
		
//		Map<String, String> data = new HashMap<>();
//		data.put("iVHCLSAN", "123456");
//		data.put("iPRTITN", "12");
//		data.put("lVHCLSOLD", "Y");
		/*
		 when(rs.getString("I_VHCL_SAN")).thenReturn("123456");
         when(rs.getString("I_VHCL_SAN").trim()).thenReturn("123456");
         when(rs.getString("I_PRTITN")).thenReturn("12");
         when(rs.getString("I_PRTITN").trim()).thenReturn("123456");
         when(rs.getString("L_VHCL_SOLD")).thenReturn("X");
         when(rs.getString("L_VHCL_SOLD").trim()).thenReturn("X");
		
		when(jdbcTemplate.query(anyString(), any(PreparedStatementSetter.class),any(ResultSetExtractor.class)))
        .thenAnswer(invocationOnMock -> {
                      PreparedStatementSetter prepSetter = invocationOnMock.getArgument(1,PreparedStatementSetter.class);
                      prepSetter.setValues(ps);
                      ResultSetExtractor<String> resultSetExtractor = invocationOnMock.getArgument(2, ResultSetExtractor.class);
                      resultSetExtractor.extractData(rs);
                      return null;
                });*/
		/*
		 * stmt.setString(2, responseBean.getVin());
		 * 
		 * when(jdbcTemplate.query(Mockito.anyString(),
		 * any(PreparedStatementSetter.class),
		 * any(ResultSetExtractor.class))).thenReturn(rs);
		 * when(rs.next()).thenReturn(true, false);
		 * Mockito.when(jdbcTemplate.query(Mockito.anyString(),
		 * Mockito.any(PreparedStatementSetter.class),Mockito.any(ResultSetExtractor.
		 * class))) .thenAnswer(invocationOnMock -> { PreparedStatementSetter prepSetter
		 * = invocationOnMock.getArgument(1,PreparedStatementSetter.class);
		 * prepSetter.setValues(stmt); ResultSetExtractor<Object> resultSetExtractor =
		 * invocationOnMock.getArgument(2, ResultSetExtractor.class);
		 * resultSetExtractor.extractData(rs); return
		 * resultSetExtractor.extractData(rs); });
		 */
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);	
	}
	
	@Test
	public void testdidiEligibilityServiceElseRodate() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setVin("1C6RR6KG8ES221908");
		requestBean.setDealerCode("99970");
		requestBean.setDealerZone("74");
		requestBean.setDealerLanguage("010");
		requestBean.setSource("SRLIB");
		requestBean.setLop("18020202");
		requestBean.setInServiceDate("2023-10-20");
		
		RepairOrderBean orderBean = new RepairOrderBean();
		orderBean.setOpenDate("2023");
		
		List<RepairOrderBean> list = new ArrayList<>();
		list.add(orderBean);
		
		requestBean.setRoData(list);
		
		DIDIResponse response = serviceImpl.didiEligibilityService(requestBean);

		assertNotNull(response);
		
	}
	
	@Test
	public void testformatDateToString() {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		String str = serviceImpl.formatDateToString(null, "yyyy-MM-DD", "2hj");
		assertEquals(null,str);
		
		String str1 = serviceImpl.formatDateToString(new Date(0), "yyyy-MM-DD", null);
		assertNotNull(str1);
	}
	
	@Test
	public void testcalculateMIS() throws DIDIException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setInServiceDate("2024-01-13");
		String str = serviceImpl.calculateMIS(requestBean);
		assertNotNull(str);
						
	}
	
	@Test
	public void testcalculateMISAtROAndLN() throws DIDIException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		requestBean.setInServiceDate("2024-01-13");
		int str = serviceImpl.calculateMISAtROAndLN("2024-01-09","2024-01-13");
		assertNotNull(str);
						
	}
	
	
	
	@Test(expected=NullPointerException.class)
	public void testsetResponseIfProcessContinueselse() throws DIDIException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		requestBean.setInServiceDate("unsold");
		requestBean.setLop("18");
		DIDIResponseBean responseBean1 = serviceImpl.setResponseIfProcessContinues( requestBean);
		assertNotNull(responseBean1);
		
	}
	
	@Test(expected=NullPointerException.class)
	public void testsetResponseIfProcessContinueselse1() throws DIDIException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		requestBean.setLop("1823");
		DIDIResponseBean responseBean1 = serviceImpl.setResponseIfProcessContinues( requestBean);
		assertNotNull(responseBean1);
		
	}
	
	@Test(expected=NullPointerException.class)
	public void testsetResponseIfProcessContinueselse2() throws DIDIException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		requestBean.setLop("182345");
		DIDIResponseBean responseBean1 = serviceImpl.setResponseIfProcessContinues( requestBean);
		assertNotNull(responseBean1);
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Test//(expected=NullPointerException.class)
	public void testsetResponseIfProcessContinues() throws DIDIException, SQLException {
		serviceImpl =  new DIDIEligibilityServiceImpl();
		
		Map<String, Object> dataMap1 = new HashMap<>();
		  dataMap1.put("brand", "RRR"); 
		  dataMap1.put("modelYear", "2014");
		  dataMap1.put("bodyStyle", "DS1L98"); 
		  dataMap1.put("engine", "ERB");
		  dataMap1.put("transmission", "DFL"); 
		  dataMap1.put("requestBean",requestBean); 
		  dataMap1.put("lop12", "18"); 
		  dataMap1.put("lop34", "20");
		  dataMap1.put("lop56", "20"); 
		  dataMap1.put("lop78", "22");
		  dataMap1.put("Q_MIS", "3");
		  
		  stmt.setString(1, requestBean.getDealerMarket()); 
		  stmt.setString(2, (String) dataMap1.get("brand")); 
		  stmt.setString(3, (String) dataMap1.get("modelYear")); 
		  stmt.setString(4, (String) dataMap1.get("bodyStyle")); 
		  stmt.setString(5, (String) dataMap1.get("engine"));
		  stmt.setString(6, (String) dataMap1.get("transmission")); 
		  stmt.setString(7, requestBean.getDealerCode()); 
		  stmt.setString(8, requestBean.getDealerZone()); 
		  stmt.setString(9, requestBean.getDealerLanguage()); 
		  stmt.setString(10, (String) dataMap1.get("lop12")); 
		  stmt.setString(11, (String) dataMap1.get("lop34"));
		  stmt.setString(12, (String) dataMap1.get("lop56")); 
		  stmt.setString(13, (String) dataMap1.get("lop78"));
		  
		  List<Map<String, String>> data = new ArrayList<>();
			Map<String, String> dataMap = new HashMap<>(); 
		  	dataMap.put("C_MKT", "M");
			dataMap.put("C_BRND", "DODGE");
			dataMap.put("I_MOD_YR", "2023");
			dataMap.put("C_BODY_MODEL", "MPJP74");
			dataMap.put("C_ENGINE_SC", "EZL");
			dataMap.put("C_TRANS_SC", "DFT");
			dataMap.put("C_DLR", "60009");
			dataMap.put("C_ZONE", "66");
			dataMap.put("C_LANG", "010");
			dataMap.put("Q_MIS", "3");
			dataMap.put("LOP1_2", "18");
			dataMap.put("LOP3_4", "U4");		
			dataMap.put("LOP5_6", "91"); 
			dataMap.put("LOP7_8", "82");
			dataMap.put("L_ELIG", "N");
			dataMap.put("X_MSG", "DIDI is required for all warranty repairs on this vehicle which has a body model WKTH74. There are some std SC...");
			
			Map<String, String> dataMap2 = new HashMap<>(); 
		  	dataMap2.put("C_MKT", "U");
			dataMap2.put("C_BRND", "DODGE");
			dataMap2.put("I_MOD_YR", "2023");
			dataMap2.put("C_BODY_MODEL", "MPJP74");
			dataMap2.put("C_ENGINE_SC", "EZL");
			dataMap2.put("C_TRANS_SC", "DFT");
			dataMap2.put("C_DLR", "60009");
			dataMap2.put("C_ZONE", "66");
			dataMap2.put("C_LANG", "010");
			dataMap2.put("Q_MIS", "3");
			dataMap2.put("LOP1_2", "18");
			dataMap2.put("LOP3_4", "U4");		
			dataMap2.put("LOP5_6", "91"); 
			dataMap2.put("LOP7_8", "82");
			dataMap2.put("L_ELIG", "N");
			dataMap2.put("X_MSG", "DIDI is required for all warranty repairs on this vehicle which has a body model WKTH74. There are some std SC...");
			
			data.add(dataMap);
			data.add(dataMap2);
		  
		  List<Map<String, String>> jdbcResponse = new ArrayList<>();
		 // when(jdbcTemplate.query(Mockito.anyString(), any(PreparedStatementSetter.class), any(ResultSetExtractor.class))).thenReturn(jdbcResponse);
		  
		  //when(jdbcTemplate.query(Mockito.anyString(), any(PreparedStatementSetter.class), any(ResultSetExtractor.class))).thenReturn(jdbcResponse);
	      when(rs.next()).thenReturn(true, false);
	      Mockito.when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(PreparedStatementSetter.class),Mockito.any(ResultSetExtractor.class)))
	      .thenAnswer(invocationOnMock -> {
	                    PreparedStatementSetter prepSetter = invocationOnMock.getArgument(1,PreparedStatementSetter.class);
	                    prepSetter.setValues(stmt);
	                    ResultSetExtractor<Object> resultSetExtractor = invocationOnMock.getArgument(2, ResultSetExtractor.class) ;
	                    Mockito.when(rs.getMetaData()).thenReturn(metaData);
	                    Mockito.when(metaData.getColumnCount()).thenReturn(3);
	                    Mockito.when(metaData.getColumnName(anyInt())).thenReturn("C_ENGINE_SC");
	                    Mockito.when(metaData.getColumnName(anyInt())).thenReturn("brand");
	                    Object obj="data";
	                    Mockito.when(rs.getObject(anyInt())).thenReturn(obj);
	                    resultSetExtractor.extractData(rs);
	                    //metaData.getColumnCount();
	                    return data;
	              });
		
		DIDIResponseBean responseBean1 = serviceImpl.setResponseIfProcessContinues( requestBean);
		assertNotNull(responseBean1);
		
	}	
	
}
